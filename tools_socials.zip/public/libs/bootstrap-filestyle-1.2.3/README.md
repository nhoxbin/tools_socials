
# [Bootstrap FileStyle v1.2.3 Stable](http://markusslima.github.io/bootstrap-filestyle/)

Bootstrap FileStyle is a quick and simple plugin to help style your form's file upload inputs.

------------------------------------------------------------------------------------
# Alert

### **Please send to (issues) problems with the plugin, also send more details as:**
* Browser
* Version
* Examples using [jsfiddle.net](https://jsfiddle.net/)
* Other plugins involved
* Etc.
 
**Detail the most of your problem to speed up the correction process.**

Thank you!

-------------------------------------------------------------------------------------

Maintained by [Markus Lima](https://github.com/markusslima) [@markusslima](https://twitter.com/markusslima)

### Getting Started, Documentation and Examples
http://markusslima.github.io/bootstrap-filestyle/

### Bug tracker

Have a bug or a feature request? [Please open a new issue](https://github.com/markusslima/bootstrap-filestyle/issues).

### Copyright and license

MIT Licence.
