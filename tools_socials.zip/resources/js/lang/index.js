import en from './en';
import vi from './vi';

export default {
	vi: {
		message: vi
	},
	en: {
		message: en
	}
}