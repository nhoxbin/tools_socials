[
    {
        "id": 1,
        "name": "Mia Mabanta",
        "avatar": "http://reactify.theironnetwork.org/data/images/user-1.jpg",
        "profile": "http://reactify.theironnetwork.org/data/images/client-1.png",
        "designation": "UI Developer",
        "body": "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English."
    },
    {
        "id": 2,
        "name": "Emmy Loren",
        "avatar": "http://reactify.theironnetwork.org/data/images/user-2.jpg",
        "profile": "http://reactify.theironnetwork.org/data/images/client-2.png",
        "designation": "UX Developer",
        "body": "Sed consequat lobortis risus, vitae congue nulla tempor id. Curabitur eu augue id nibh tristique tristique. Phasellus vel est nisi"
    },
    {
        "id": 3,
        "name": "Astell Mercell",
        "avatar": "http://reactify.theironnetwork.org/data/images/user-3.jpg",
        "profile": "http://reactify.theironnetwork.org/data/images/client-3.png",
        "designation": "Director of Brand Development at Quartz",
        "body": "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English."
    }
]