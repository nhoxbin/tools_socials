<template>
	<page-title-bar></page-title-bar>
</template>
<script>
export default {
	data: function() {
		return {
			
		}
	},
	mounted() {
		// console.log(this.$auth.user().email);
	},
	methods: {

	}
}
</script>