<template>
   <div class="category-progress-wrap">
      <div class="d-custom-flex">
         <span class="mr-3 label">Clothing</span>
         <div class="progress-wrap">
            <span>75%</span>
            <v-progress-linear value="75" height="24" color="info"></v-progress-linear>
         </div>
      </div>
      <div class="d-custom-flex">
         <span class="mr-3 label">Gadgets</span>
         <div class="progress-wrap">
            <span>45%</span>
            <v-progress-linear value="45" height="24" color="info"></v-progress-linear>
         </div>
      </div>
      <div class="d-custom-flex">
         <span class="mr-3 label">Furniture</span>
         <div class="progress-wrap">
            <span>83%</span>
            <v-progress-linear value="83" height="24" color="info"></v-progress-linear>
         </div>
      </div>
      <div class="d-custom-flex">
         <span class="mr-3 label">Wine</span>
         <div class="progress-wrap">
            <span>15%</span>
            <v-progress-linear value="15" height="24" color="info"></v-progress-linear>
         </div>
      </div>
      <div class="d-custom-flex">
         <span class="mr-3 label">Toys</span>
         <div class="progress-wrap">
            <span>58%</span>
            <v-progress-linear value="58" height="24" color="info"></v-progress-linear>
         </div>
      </div>
      <div class="d-custom-flex">
         <span class="mr-3 label">Nutrition</span>
         <div class="progress-wrap">
            <span>39%</span>
            <v-progress-linear value="39" height="24" color="info"></v-progress-linear>
         </div>
      </div>
   </div>
</template>