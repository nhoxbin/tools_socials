<template>
   <div class="media pos-relative">
		<img src="/static/avatars/user-12.jpg" class="img-responsive rounded-circle mr-4" alt="user profile" width="95" height="95" />
		<div class="media-body">
			<span class="pink--text">Request</span>
			<h2>Andre Hicks</h2>
			<span>Sr. Develoepr @Oracle</span>
			<div class="btn-wrapper">
			<v-btn color="success">Accept</v-btn>
			<v-btn color="error">Reject</v-btn>
			</div>
		</div>
		<v-avatar color="warning" class="overlap">
			<v-icon dark>ti-id-badge</v-icon>
		</v-avatar>
	</div>
</template>
