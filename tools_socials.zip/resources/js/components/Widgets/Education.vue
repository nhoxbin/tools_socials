<template>
   <v-list two-line>
		<v-list-tile>
			<v-list-tile-content>
			<v-list-tile-sub-title>
				<h5 class="fw-bold gray--text">Product Designer</h5>
				<span>AirHelper - London, United Kingdom</span>
			</v-list-tile-sub-title>
			</v-list-tile-content>
			<v-list-tile-action>
			<span class="small">2016 - 2017</span>
			</v-list-tile-action>
		</v-list-tile>
		<v-list-tile>
			<v-list-tile-content>
			<v-list-tile-sub-title>
				<h5 class="fw-bold gray--text">App Designer</h5>
				<span>AirHelper - London, United Kingdom</span>
			</v-list-tile-sub-title>
			</v-list-tile-content>
			<v-list-tile-action>
			<span class="small">2017 - 2018</span>
			</v-list-tile-action>
		</v-list-tile>
		<v-list-tile>
			<v-list-tile-content>
			<v-list-tile-sub-title>
				<h5 class="fw-bold gray--text">Service Designer</h5>
				<span>AirHelper - London, United Kingdom</span>
			</v-list-tile-sub-title>
			</v-list-tile-content>
			<v-list-tile-action>
			<span class="small">2015 - 2016</span>
			</v-list-tile-action>
		</v-list-tile>
	</v-list>
</template>
