export default {
   primary: '#FFB70F',
   secondary: '#424242',
   accent: '#82B1FF',
   error: '#FF3739',
   info: '#00D0BD',
   success: '#00D014',
   warning: '#5D92F4'
}